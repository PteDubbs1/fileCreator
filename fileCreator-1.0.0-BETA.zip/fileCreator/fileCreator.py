
#Global
import sys
sys.stdout.write("\x1b]2;File Creator App\x07")
import os
homedir = os.environ['HOME']
name = ""
ext = ""
type = 1

#get Vars
os.system('clear')
print("What is the name of the new file?")
name = input("Enter your responce: ")
os.system('clear')
print("What type of file is it? (Text, Python, Html)")
name2 = input("Enter your responce: ")

#Figure out where to put the file
os.system('clear')
print("Where would you like to save this file?")
print("1)Desktop| 2)Creator save file")
where = input("Enter your responce: ")

if where == "1":
    place = "/Desktop/"
if where == "2":
    place = "/fileCreator/createdFiles/"
path = homedir + place

#Create file it's self
if name != "":  
    if name2 == "text":
        ext = ".txt"
        type = 1
    elif name2 == "python":
        ext = ".py"
        type = 2
    elif name2 == "html":
        ext = ".html"
        type = 3

#Create the file       
f = open(path + name + ext ,  "x")
if type == 1:
    f.write("")
elif type == 2:
    f.write("import os")
elif type == 3:
    f.write("<html>\n<head><title></title>\n\n</head>\n<body>\n\n</body>\n</html>")
f.close()
print("Completed!")

os.system('clear')
print("Would you like to exit?")
print("1)Yes | 2)No")
yorn = input("Enter your responce: ")

if yorn == "1":
    print("Thank you for using!")
    exit()
    
